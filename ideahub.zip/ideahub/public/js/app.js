'use strict';

/* ══ AUTH STATE ══ */
let _authMode='login';

function switchAuthTab(mode){
  _authMode=mode;
  document.querySelectorAll('.auth-tab').forEach((b,i)=>
    b.classList.toggle('active',(mode==='login'&&i===0)||(mode==='reg'&&i===1))
  );
  document.getElementById('form-login').style.display=mode==='login'?'flex':'none';
  document.getElementById('form-reg').style.display=mode==='reg'?'flex':'none';
  clearAuthErr();
}

function showAuthErr(msg){
  const el=document.getElementById('auth-err');
  el.textContent=msg;el.classList.add('on');
}
function clearAuthErr(){
  document.getElementById('auth-err').classList.remove('on');
}

async function doLogin(){
  clearAuthErr();
  const username=(document.getElementById('li-user').value||'').trim();
  const password=document.getElementById('li-pass').value||'';
  if(!username||!password){showAuthErr('Login va parolni kiriting');return;}
  const btn=document.getElementById('login-btn');
  btn.disabled=true;
  btn.innerHTML=`<div class="spin" style="width:16px;height:16px;margin:0;border-top-color:var(--dark)"></div>`;
  try{
    const d=await API.login(username,password);
    Tok.set(d.token);
    localStorage.setItem('ih_tok',d.token);
    await boot(d.user);
  }catch(err){
    showAuthErr(err.message||'Noto\'g\'ri login yoki parol');
    btn.disabled=false;
    btn.innerHTML=`${IC.check} Kirish`;
  }
}

async function doRegister(){
  clearAuthErr();
  const name=(document.getElementById('re-name').value||'').trim();
  const username=(document.getElementById('re-user').value||'').trim();
  const email=(document.getElementById('re-mail').value||'').trim();
  const password=document.getElementById('re-pass').value||'';
  if(!name||!username||!email||!password){showAuthErr('Barcha maydonlarni to\'ldiring');return;}
  if(password.length<6){showAuthErr('Parol kamida 6 belgi bo\'lsin');return;}
  const btn=document.getElementById('reg-btn');
  btn.disabled=true;
  btn.innerHTML=`<div class="spin" style="width:16px;height:16px;margin:0;border-top-color:var(--dark)"></div>`;
  try{
    const d=await API.register(name,username,email,password);
    Tok.set(d.token);
    localStorage.setItem('ih_tok',d.token);
    await boot(d.user);
  }catch(err){
    showAuthErr(err.message||'Xatolik yuz berdi');
    btn.disabled=false;
    btn.innerHTML=`${IC.plus} Ro'yxatdan o'tish`;
  }
}

/* Enter key support */
function authKeydown(e){if(e.key==='Enter')_authMode==='login'?doLogin():doRegister();}

/* ══ BOOT ══ */
async function boot(initialUser){
  document.getElementById('auth').style.display='none';
  document.getElementById('app').classList.add('vis');

  window._me=initialUser||await API.me();
  syncTopbar(window._me);

  WS.connect(Tok.get());
  initFeedWS();initMsgWS();initNotifWS();

  await Promise.all([
    loadFeed(true),
    loadNotifCount(),
    loadConvos(),
    loadMyComs(),
    loadPopularComs(),
    initComPicker(),
  ]);
  initScrollFeed();

  document.querySelectorAll('.lsb-btn[data-sec]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const s=btn.dataset.sec;
      goSec(s);
      if(s==='notifs'){loadNotifs();markNotifs();}
      if(s==='msgs')loadConvos();
      if(s==='user'||s==='profile')openUser(window._me.id);
      if(s==='settings')loadSettings();
      if(s==='saved')loadSaved();
    });
  });
}

function syncTopbar(u){
  /* topbar */
  const av=document.getElementById('tb-av');
  if(av){
    av.style.cssText=avStyle(u,30)+';border-radius:50%;';
    av.innerHTML=u.avatar
      ?`<img src="${esc(u.avatar)}" style="width:100%;height:100%;object-fit:cover" alt="">`
      :`<span style="font-size:10px;font-weight:800;color:var(--dark)">${initials(u.name||u.username)}</span>`;
  }
  const nm=document.getElementById('tb-av-name');if(nm)nm.textContent=u.name||u.username;
  const kr=document.getElementById('tb-av-karma');if(kr)kr.textContent=fmtNum(u.karma||0)+' karma';

  /* sidebar */
  const sav=document.getElementById('sb-av');
  if(sav){
    sav.style.cssText=avStyle(u,28)+';border-radius:50%;';
    sav.innerHTML=u.avatar
      ?`<img src="${esc(u.avatar)}" style="width:100%;height:100%;object-fit:cover" alt="">`
      :`<span style="font-size:9px;font-weight:800;color:var(--dark)">${initials(u.name||u.username)}</span>`;
  }
  const sunm=document.getElementById('sb-uname');if(sunm)sunm.textContent='u/'+u.username;
}
window.syncTopbar=syncTopbar;

/* ══ SAVED ══ */
async function loadSaved(){
  const el=document.getElementById('saved-cnt');if(!el)return;
  el.innerHTML=spinner();
  try{
    const posts=await API.savedPosts();
    el.innerHTML='';
    if(!posts.length){el.innerHTML=emptyEl('save','Hali saqlangan postlar yo\'q');return;}
    posts.forEach((p,i)=>{const d=document.createElement('div');d.innerHTML=buildPost(p);const c=d.firstElementChild;c.style.animationDelay=(i*.04)+'s';el.appendChild(c);});
  }catch(e){el.innerHTML=emptyEl('close','Xatolik',e.message);}
}

/* ══ LOGOUT ══ */
function doLogout(){
  WS.disconnect();Tok.clr();localStorage.removeItem('ih_tok');
  window._me=null;
  document.getElementById('app').classList.remove('vis');
  document.getElementById('auth').style.display='flex';
  toast('Chiqildi');
}

/* ══ INIT ══ */
(async function init(){
  const saved=localStorage.getItem('ih_tok');
  if(saved){
    Tok.set(saved);
    try{const u=await API.me();await boot(u);return;}
    catch{localStorage.removeItem('ih_tok');Tok.clr();}
  }
})();

window.switchAuthTab=switchAuthTab;window.doLogin=doLogin;window.doRegister=doRegister;
window.authKeydown=authKeydown;window.boot=boot;window.doLogout=doLogout;window.loadSaved=loadSaved;
