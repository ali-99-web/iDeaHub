'use strict';
/* ══ COMMUNITIES ══ */
async function openCommunity(slug){
  _curCom=slug;
  goSec('community');
  const hd=document.getElementById('com-hd-area');
  const fd=document.getElementById('com-feed-cnt');
  if(hd)hd.innerHTML=spinner();if(fd)fd.innerHTML=spinner();
  try{
    const [com,posts]=await Promise.all([API.getCom(slug),API.comPosts(slug,'hot',0)]);
    if(hd)hd.innerHTML=`
      <div class="com-page-hd">
        <div class="com-banner" style="background:linear-gradient(135deg,${esc(com.color||'#E8B84B')}44,${esc(com.color||'#E8B84B')}22)"></div>
        <div class="com-hd-row">
          <div class="com-hd-icon" style="background:${esc(com.color||'#E8B84B')}33;border:2px solid ${esc(com.color||'#E8B84B')}55">
            ${IC.people}
          </div>
          <div class="com-hd-info">
            <div class="com-hd-name">i/${esc(com.slug)}</div>
            <div class="com-hd-sub">${esc(com.name)} &middot; ${fmtNum(com.members)} a'zo</div>
          </div>
          <div style="margin-left:auto;display:flex;gap:8px;align-items:center">
            ${com.is_owner?`<button class="btn btn-ghost" style="padding:7px 14px;font-size:12px" onclick="editCom('${esc(com.slug)}')">${IC.settings} Sozlash</button>`:''}
            <button class="btn ${com.is_member?'btn-outline':'btn-gold'}" id="jb-${esc(com.id)}" onclick="toggleJoin('${esc(com.slug)}','${esc(com.id)}',this)">
              ${com.is_member?`${IC.check} A'zo`:`${IC.plus} Qo'shilish`}
            </button>
          </div>
        </div>
        ${com.description?`<div style="padding:0 18px 16px;font-size:13px;color:var(--tx3)">${esc(com.description)}</div>`:''}
      </div>`;
    if(fd){
      fd.innerHTML='';
      document.querySelectorAll('#com-sort-bar .sort-btn').forEach(b=>b.classList.toggle('active',b.dataset.sort==='hot'));
      _comOff=0;
      posts.forEach((p,i)=>{
        const d=document.createElement('div');d.innerHTML=buildPost(p);
        const c=d.firstElementChild;c.style.animationDelay=(i*.04)+'s';fd.appendChild(c);
      });
      if(!posts.length)fd.innerHTML=emptyEl('save','Hali postlar yo\'q','Bu jamoada birinchi post siz bo\'ling!');
    }
    buildComRsb(com);
  }catch(e){if(hd)hd.innerHTML=emptyEl('close','Jamoa topilmadi',e.message);}
}

async function toggleJoin(slug,comId,btn){
  try{
    const d=await API.joinCom(slug);
    if(btn){
      btn.className=`btn ${d.joined?'btn-outline':'btn-gold'}`;
      btn.innerHTML=d.joined?`${IC.check} A'zo`:`${IC.plus} Qo'shilish`;
    }
    toast(d.joined?'Jamoaga qo\'shildingiz':'Jamoadan chiqdingiz');
    loadMyComs();
  }catch(e){toast(e.message);}
}

async function loadMyComs(){
  try{
    const coms=await API.mineComs();
    const el=document.getElementById('my-coms');if(!el)return;
    el.innerHTML='';
    coms.slice(0,10).forEach(c=>{
      const b=document.createElement('button');
      b.className='com-lsb';b.onclick=()=>openCommunity(c.slug);
      b.innerHTML=`<span class="com-lsb-dot" style="background:${esc(c.color||'#E8B84B')}"></span>i/${esc(c.slug)}`;
      el.appendChild(b);
    });
  }catch{}
}

async function loadPopularComs(){
  try{
    const coms=await API.popularComs();
    const el=document.getElementById('popular-cnt');if(!el)return;
    el.innerHTML='';
    coms.forEach((c,i)=>{
      const d=document.createElement('div');
      d.style.cssText='display:flex;align-items:center;gap:10px;padding:11px 0;border-bottom:1px solid var(--glass-bd);cursor:pointer;transition:all .2s;';
      d.innerHTML=`
        <span style="font-size:11px;font-weight:800;color:var(--tx4);font-family:\'Syne\',sans-serif;width:18px">${i+1}</span>
        <span style="width:30px;height:30px;border-radius:50%;background:${esc(c.color||'#E8B84B')}33;border:1.5px solid ${esc(c.color||'#E8B84B')}55;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:${esc(c.color||'#E8B84B')}">${IC.people}</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:13px;font-weight:700;font-family:\'Syne\',sans-serif">i/${esc(c.slug)}</div>
          <div style="font-size:11px;color:var(--tx4)">${fmtNum(c.members)} a'zo</div>
        </div>
        <button class="btn ${c.is_member?'btn-outline':'btn-gold'}" style="padding:5px 12px;font-size:12px" onclick="event.stopPropagation();toggleJoin('${esc(c.slug)}','${esc(c.id)}',this)">
          ${c.is_member?IC.check:`${IC.plus}`}
        </button>`;
      d.onclick=()=>openCommunity(c.slug);
      d.onmouseover=()=>d.style.opacity='.85';
      d.onmouseout=()=>d.style.opacity='1';
      el.appendChild(d);
    });
  }catch{}
}

function buildComRsb(com){
  const el=document.getElementById('rsb-inner');if(!el)return;
  const card=el.querySelector('.rsb-com-card');if(card)card.remove();
  const div=document.createElement('div');
  div.className='rsb-card rsb-com-card';
  div.innerHTML=`
    <div class="rsb-banner" style="background:linear-gradient(135deg,${esc(com.color||'#E8B84B')}44,${esc(com.color||'#E8B84B')}11)"></div>
    <div class="rsb-body">
      <div class="rsb-title">i/${esc(com.slug)}</div>
      <div class="rsb-desc">${esc(com.description||'Bu jamoa haqida.')}</div>
      <div class="rsb-stat"><span>A'zolar</span><strong>${fmtNum(com.members)}</strong></div>
      <div class="rsb-stat"><span>Asos solgan</span><strong>u/${esc(com.oname||'')}</strong></div>
      <button class="btn btn-gold" style="width:100%;margin-top:12px" onclick="openSubmit('${esc(com.slug)}')">${IC.edit} Post qo'shish</button>
    </div>`;
  el.prepend(div);
}

/* ══ CREATE COMMUNITY ══ */
function openCreateCom(){document.getElementById('cc-overlay').classList.add('open');}
function closeCreateCom(){document.getElementById('cc-overlay').classList.remove('open');}
async function doCreateCom(){
  const slug=(document.getElementById('nc-slug').value||'').trim().toLowerCase();
  const name=(document.getElementById('nc-name').value||'').trim();
  const desc=(document.getElementById('nc-desc').value||'').trim();
  const color=document.querySelector('[name="nc-color"]:checked')?.value||'#E8B84B';
  if(!slug||!name){toast('Slug va nom kiritish shart');return;}
  try{
    const com=await API.createCom({slug,name,description:desc,color});
    closeCreateCom();toast('Jamoa yaratildi');
    loadMyComs();openCommunity(com.slug);
  }catch(e){toast(e.message);}
}

/* ══ SUBMIT POST ══ */
let _subTab='text',_allComs=[];
function openSubmit(comSlug){
  document.getElementById('sub-overlay').classList.add('open');
  if(comSlug){const inp=document.getElementById('sub-com-inp');if(inp)inp.value=comSlug;}
}
function closeSubmit(){document.getElementById('sub-overlay').classList.remove('open');}
function switchSubTab(t){
  _subTab=t;
  document.querySelectorAll('.sub-tab').forEach(b=>b.classList.toggle('active',b.dataset.t===t));
  document.querySelectorAll('.sub-form').forEach(f=>f.classList.toggle('active',f.dataset.f===t));
}
async function doSubmitPost(){
  const title=(document.getElementById('sub-title').value||'').trim();
  const community=(document.getElementById('sub-com-inp').value||'').trim();
  if(!title){toast('Sarlavha kiritish shart');return;}
  if(!community){toast('Jamoa tanlash shart');return;}
  const btn=document.getElementById('sub-btn');
  btn.disabled=true;btn.innerHTML=`<div class="spin" style="width:16px;height:16px;margin:0"></div>`;
  try{
    let post;
    if(_subTab==='image'){
      const fi=document.getElementById('sub-img-file');
      const fd=new FormData();
      fd.append('title',title);fd.append('community',community);fd.append('type','image');
      if(fi?.files?.[0])fd.append('image',fi.files[0]);
      post=await API.createPost(fd,true);
    } else if(_subTab==='link'){
      const link=(document.getElementById('sub-link').value||'').trim();
      post=await API.createPost({title,community,type:'link',link});
    } else {
      const body=(document.getElementById('sub-body').value||'').trim();
      post=await API.createPost({title,community,type:'text',body});
    }
    closeSubmit();toast('Post nashr qilindi');openPost(post.id);
  }catch(e){toast(e.message);}
  finally{btn.disabled=false;btn.innerHTML=`${IC.send} Nashr qilish`;}
}
async function initComPicker(){
  try{_allComs=await API.communities();}catch{}
  const inp=document.getElementById('sub-com-inp');
  const dd=document.getElementById('sub-com-dd');
  if(!inp||!dd)return;
  inp.addEventListener('input',()=>{
    const q=inp.value.toLowerCase();
    const matches=_allComs.filter(c=>c.slug.includes(q)||c.name.toLowerCase().includes(q)).slice(0,8);
    dd.innerHTML='';
    matches.forEach(c=>{
      const d=document.createElement('div');d.className='com-dd-item';
      d.innerHTML=`<span class="com-dd-dot" style="background:${esc(c.color||'#E8B84B')}"></span><div><strong>i/${esc(c.slug)}</strong> <span style="color:var(--tx4)">${esc(c.name)}</span></div>`;
      d.onclick=()=>{inp.value=c.slug;dd.classList.remove('open');};
      dd.appendChild(d);
    });
    dd.classList.toggle('open',matches.length>0&&inp.value.length>0);
  });
  document.addEventListener('click',e=>{if(!inp.contains(e.target)&&!dd.contains(e.target))dd.classList.remove('open');});
}

/* ══ SEARCH ══ */
const doSearch=debounce(async q=>{
  if(!q.trim())return;
  goSec('search');
  const el=document.getElementById('search-res');
  el.innerHTML=spinner();
  try{
    const d=await API.search(q.trim());
    el.innerHTML='';
    if(!d.posts.length&&!d.communities.length&&!d.users.length){
      el.innerHTML=emptyEl('search','Topilmadi',`"${q}" bo'yicha natija yo'q`);return;
    }
    if(d.communities.length){
      const sh=document.createElement('div');sh.className='sr-section-hd';sh.textContent='Jamoalar';el.appendChild(sh);
      d.communities.forEach(c=>{
        const dv=document.createElement('div');dv.className='sr-com';dv.onclick=()=>openCommunity(c.slug);
        dv.innerHTML=`
          <span style="width:38px;height:38px;border-radius:50%;background:${esc(c.color||'#E8B84B')}33;border:1.5px solid ${esc(c.color||'#E8B84B')}55;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:${esc(c.color||'#E8B84B')}">${IC.people}</span>
          <div style="flex:1"><div style="font-weight:700;font-size:13.5px;font-family:\'Syne\',sans-serif">i/${esc(c.slug)}</div><div style="font-size:12px;color:var(--tx4)">${fmtNum(c.members)} a'zo</div></div>
          <button class="btn ${c.is_member?'btn-outline':'btn-gold'}" style="padding:6px 14px;font-size:12px" onclick="event.stopPropagation();toggleJoin('${esc(c.slug)}','${esc(c.id)}',this)">
            ${c.is_member?IC.check:`${IC.plus}`}
          </button>`;
        el.appendChild(dv);
      });
    }
    if(d.users.length){
      const sh=document.createElement('div');sh.className='sr-section-hd';sh.textContent='Foydalanuvchilar';el.appendChild(sh);
      d.users.forEach(u=>{
        const dv=document.createElement('div');dv.className='sr-user';dv.onclick=()=>openUser(u.username);
        dv.innerHTML=`
          <div class="av" style="${avStyle(u,36)};border-radius:50%">${avHtml(u,36,13)}</div>
          <div style="flex:1"><div style="font-size:13px;font-weight:700;font-family:\'Syne\',sans-serif">u/${esc(u.username)}</div><div style="font-size:12px;color:var(--gold)">${fmtNum(u.karma||0)} karma</div></div>`;
        el.appendChild(dv);
      });
    }
    if(d.posts.length){
      const sh=document.createElement('div');sh.className='sr-section-hd';sh.textContent='Postlar';el.appendChild(sh);
      d.posts.forEach(p=>{const dv=document.createElement('div');dv.innerHTML=buildPost(p);el.appendChild(dv.firstElementChild);});
    }
  }catch(e){el.innerHTML=emptyEl('close','Xatolik',e.message);}
},320);
function onSearch(q){if(q)doSearch(q);}

/* ══ NOTIFICATIONS ══ */
let _nUnread=0;
async function loadNotifs(){
  const el=document.getElementById('notifs-list');if(!el)return;
  el.innerHTML=spinner();
  try{
    const notifs=await API.notifications();
    el.innerHTML='';
    if(!notifs.length){el.innerHTML=emptyEl('bell','Hali bildirishnomalar yo\'q');return;}
    notifs.forEach(n=>{
      const d=document.createElement('div');
      d.className=`notif${n.is_read?'':' unread'}`;
      d.innerHTML=`
        <div class="notif-ico" style="background:${n.is_read?'var(--glass)':'rgba(232,184,75,.08)'};color:${n.is_read?'var(--tx4)':'var(--gold)'}">${IC.bell}</div>
        <div style="flex:1"><div class="notif-txt">${esc(n.msg)}</div><div class="notif-ago">${n.ago}</div></div>
        ${!n.is_read?'<div class="notif-udot"></div>':''}`;
      el.appendChild(d);
    });
  }catch(e){el.innerHTML=emptyEl('close','Xatolik',e.message);}
}
async function loadNotifCount(){
  try{const d=await API.notifCount();_nUnread=d.count;updNotifDot();}catch{}
}
async function markNotifs(){
  try{await API.markRead();_nUnread=0;updNotifDot();document.querySelectorAll('.notif.unread').forEach(e=>{e.classList.remove('unread');e.querySelector('.notif-udot')?.remove();});}catch{}
}
function updNotifDot(){
  const dot=document.getElementById('notif-dot');
  const badge=document.getElementById('notif-badge');
  if(_nUnread>0){dot?.classList.add('on');if(badge){badge.textContent=_nUnread;badge.style.display='inline-flex';}}
  else{dot?.classList.remove('on');if(badge)badge.style.display='none';}
}
function initNotifWS(){
  WS.on('notif',d=>{_nUnread++;updNotifDot();toast(d.msg||'Yangi bildirishnoma');if(curSec()==='notifs')loadNotifs();});
}

/* ══ MESSAGES ══ */
let _chatWith=null,_rendered=new Set();
async function loadConvos(){
  try{
    const convos=await API.messages();
    const el=document.getElementById('conv-list');if(!el)return;
    el.innerHTML='';
    if(!convos.length){el.innerHTML='<div style="padding:20px;text-align:center;font-size:13px;color:var(--tx4)">Hali xabarlar yo\'q</div>';return;}
    convos.forEach(cv=>{
      const o=cv.other;
      const d=document.createElement('div');
      d.className=`conv${_chatWith?.id===o.id?' active':''}`;
      d.dataset.uid=o.id;d.onclick=()=>openChat(o);
      d.innerHTML=`
        <div class="av" style="${avStyle(o,36)};border-radius:50%;flex-shrink:0">${avHtml(o,36,13)}</div>
        <div class="conv-info">
          <div class="conv-name">u/${esc(o.username)}</div>
          <div class="conv-prev">${cv.last?esc(cv.last.body.slice(0,38)):'...'}</div>
        </div>
        ${cv.unread>0?'<div class="conv-dot"></div>':''}`;
      el.appendChild(d);
    });
  }catch{}
}
async function openChat(user){
  _chatWith=user;_rendered.clear();
  document.getElementById('chat-empty').style.display='none';
  const panel=document.getElementById('chat-panel');panel.classList.add('vis');
  const hd=document.getElementById('chat-hd-inner');
  if(hd)hd.innerHTML=`
    <div class="av" style="${avStyle(user,36)};border-radius:50%">${avHtml(user,36,13)}</div>
    <div style="flex:1">
      <div style="font-size:13.5px;font-weight:700;font-family:\'Syne\',sans-serif">u/${esc(user.username)}</div>
      <div style="font-size:11px;color:var(--tx4);display:flex;align-items:center;gap:5px">
        <span style="width:6px;height:6px;border-radius:50%;background:${user.online?'var(--grn)':'var(--tx4)'}"></span>
        ${user.online?'Onlayn':'Oflayn'}
      </div>
    </div>
    <button class="btn btn-ghost" style="padding:6px 13px;font-size:12px" onclick="openUser('${esc(user.username)}')">${IC.user} Profil</button>`;
  document.querySelectorAll('.conv').forEach(r=>r.classList.toggle('active',r.dataset.uid===user.id));
  const msgs=await API.thread(user.id);
  const b=document.getElementById('chat-msgs');b.innerHTML='';_rendered.clear();
  msgs.forEach(m=>addBubble(m,m.from_id===window._me?.id));
  b.scrollTop=b.scrollHeight;loadConvos();
}
function addBubble(msg,isMe){
  if(_rendered.has(msg.id))return;_rendered.add(msg.id);
  const b=document.getElementById('chat-msgs');if(!b)return;
  const d=document.createElement('div');
  d.className='bubble '+(isMe?'me':'them');d.id='bbl-'+msg.id;
  d.innerHTML=`${esc(msg.body)}<div class="b-time">${msg.ago||'Hozir'}</div>`;
  b.appendChild(d);b.scrollTop=b.scrollHeight;
}
async function sendMsg(){
  if(!_chatWith)return;
  const inp=document.getElementById('chat-inp');
  const body=(inp.value||'').trim();if(!body)return;
  inp.value='';
  try{await API.sendMsg(_chatWith.id,body);}catch(e){toast(e.message);inp.value=body;}
}
async function startChat(username){
  goSec('msgs');
  try{const u=await API.getUser(username);setTimeout(()=>openChat(u),80);}catch(e){toast(e.message);}
}
function initMsgWS(){
  WS.on('new_msg',d=>{
    toast(`${d.from.username}: ${d.msg.body.slice(0,40)}`);
    if(curSec()==='msgs'&&_chatWith?.id===d.msg.from_id)addBubble(d.msg,false);
    loadConvos();
  });
  WS.on('msg_sent',d=>{if(_chatWith?.id===d.msg.to_id)addBubble(d.msg,true);loadConvos();});
}

/* ══ PROFILE ══ */
async function openUser(param){
  goSec('user');
  const el=document.getElementById('user-cnt');el.innerHTML=spinner();
  try{
    const u=await API.getUser(param);
    el.innerHTML=`
      <div class="prof-card">
        <div class="prof-banner" style="background:linear-gradient(135deg,${esc(u.color||'#E8B84B')}55,${esc(u.color||'#E8B84B')}22,transparent)"></div>
        <div class="prof-hd">
          <div class="prof-av-wrap" style="background:${esc(u.color||'#E8B84B')}">
            ${u.avatar?`<img src="${esc(u.avatar)}" alt="">`:`<span style="color:var(--dark)">${initials(u.name||u.username)}</span>`}
          </div>
          <div class="prof-info">
            <div class="prof-name">${esc(u.name)}</div>
            <div class="prof-uname">u/${esc(u.username)} ${u.online?'<span style="color:var(--grn);font-size:11px">● Onlayn</span>':''}</div>
            <div class="prof-bio">${esc(u.bio||'Bio yo\'q...')}</div>
            <div class="prof-stats">
              <div><div class="ps-n">${fmtNum(u.karma||0)}</div><div class="ps-l">Karma</div></div>
              <div><div class="ps-n">${u.posts?.length||0}</div><div class="ps-l">Post</div></div>
            </div>
            <div class="prof-acts">
              ${u.is_me
                ?`<button class="btn btn-gold" onclick="goSec('settings');loadSettings()">${IC.settings} Sozlamalar</button>`
                :`<button class="btn btn-gold" onclick="startChat('${esc(u.username)}')">${IC.msg} Xabar</button>`
              }
            </div>
          </div>
        </div>
      </div>
      <div style="font-size:11px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--tx4);padding:8px 0 10px;font-family:\'Syne\',sans-serif">Postlari</div>
      <div id="user-posts-cnt"></div>`;
    const pc=document.getElementById('user-posts-cnt');
    if(!u.posts?.length){pc.innerHTML=emptyEl('save','Hali post yo\'q');}
    else u.posts.forEach((p,i)=>{const d=document.createElement('div');d.innerHTML=buildPost(p);const c=d.firstElementChild;c.style.animationDelay=(i*.04)+'s';pc.appendChild(c);});
  }catch(e){el.innerHTML=emptyEl('close','Topilmadi',e.message);}
}

/* ══ SETTINGS ══ */
async function loadSettings(){
  const el=document.getElementById('settings-cnt');if(!el)return;
  el.innerHTML=spinner();
  try{
    const u=window._me;
    el.innerHTML=`
      <div class="set-card">
        <div class="set-title">${IC.cam} Profil rasmi</div>
        <div class="av-upload">
          <div class="av-big" id="av-big-prev" style="background:${esc(u.color||'#E8B84B')}" onclick="document.getElementById('av-inp').click()">
            ${u.avatar?`<img src="${esc(u.avatar)}" alt="">`:`<span style="color:var(--dark)">${initials(u.name||u.username)}</span>`}
          </div>
          <div class="av-upload-info">
            <p>Profil rasmingiz</p>
            <small>JPG, PNG, WEBP — 5MB gacha</small>
            <label class="av-file-btn">
              ${IC.upload} Yuklash
              <input type="file" accept="image/*" id="av-inp" style="display:none" onchange="uploadAvatar(this)">
            </label>
          </div>
        </div>
      </div>
      <div class="set-card">
        <div class="set-title">${IC.user} Ma'lumotlar</div>
        <div class="form-row"><div class="form-lbl">Ism</div><input class="inp" id="st-name" value="${esc(u.name||'')}"></div>
        <div class="form-row"><div class="form-lbl">Email</div><input class="inp" value="${esc(u.email||'')}" disabled></div>
        <div class="form-row" style="margin-bottom:0"><div class="form-lbl">Bio</div><textarea class="inp" id="st-bio" rows="3">${esc(u.bio||'')}</textarea></div>
        <button class="btn btn-gold" style="width:100%;padding:11px;margin-top:16px" onclick="saveProfile()">${IC.check} Saqlash</button>
      </div>
      <div class="set-card" style="border-color:rgba(255,82,82,.2)">
        <div class="set-title" style="color:var(--red)">${IC.logout} Chiqish</div>
        <p style="font-size:13px;color:var(--tx4);margin-bottom:16px">Hisobingizdan chiqib ketasiz.</p>
        <button onclick="doLogout()" class="btn btn-danger" style="width:100%;padding:10px">${IC.logout} Chiqish</button>
      </div>`;
  }catch(e){el.innerHTML=emptyEl('close','Xatolik',e.message);}
}
async function saveProfile(){
  const name=(document.getElementById('st-name').value||'').trim();
  const bio=(document.getElementById('st-bio').value||'').trim();
  if(!name){toast('Ism bo\'sh bo\'lmasin');return;}
  try{const u=await API.updateMe(name,bio);window._me={...window._me,...u};syncTopbar(window._me);toast('Profil saqlandi');}
  catch(e){toast(e.message);}
}
async function uploadAvatar(inp){
  const file=inp.files?.[0];if(!file)return;
  try{
    const fd=new FormData();fd.append('image',file);
    const d=await API.uploadAv(fd);
    window._me.avatar=d.avatar;syncTopbar(window._me);toast('Rasm yangilandi');
    const prev=document.getElementById('av-big-prev');
    if(prev)prev.innerHTML=`<img src="${esc(d.avatar)}" alt="" style="width:100%;height:100%;object-fit:cover">`;
  }catch(e){toast(e.message);}
}

window.openCommunity=openCommunity;window.toggleJoin=toggleJoin;window.loadMyComs=loadMyComs;window.loadPopularComs=loadPopularComs;
window.openCreateCom=openCreateCom;window.closeCreateCom=closeCreateCom;window.doCreateCom=doCreateCom;
window.openSubmit=openSubmit;window.closeSubmit=closeSubmit;window.switchSubTab=switchSubTab;window.doSubmitPost=doSubmitPost;window.initComPicker=initComPicker;
window.onSearch=onSearch;
window.loadNotifs=loadNotifs;window.loadNotifCount=loadNotifCount;window.markNotifs=markNotifs;window.updNotifDot=updNotifDot;window.initNotifWS=initNotifWS;
window.loadConvos=loadConvos;window.openChat=openChat;window.addBubble=addBubble;window.sendMsg=sendMsg;window.startChat=startChat;window.initMsgWS=initMsgWS;
window.openUser=openUser;
window.loadSettings=loadSettings;window.saveProfile=saveProfile;window.uploadAvatar=uploadAvatar;
