'use strict';
const fs=require('fs');const path=require('path');const url=require('url');
const {db,Q,hmac}=require('./db');
const {uid,hashPass,makeToken,getAuth,timeAgo,readBody,parseMultipart,json,randColor}=require('./helpers');
const ws=require('./ws');
const UPLOAD=path.join(__dirname,'..','uploads');

const fmt=r=>({...r,ago:timeAgo(r.created_at)});
function fmtPost(p,u2){
  const v=u2?(Q.pvGet.get(u2,p.id)||{vote:0}):{vote:0};
  const s=u2?!!Q.svCheck.get(u2,p.id):false;
  return{...fmt(p),my_vote:v.vote,saved:s};
}
function fmtCom(c,u2){return{...c,is_member:u2?!!Q.memCheck.get(u2,c.id):false,is_owner:c.owner_id===u2};}
function fmtComment(c,u2){const v=u2?(Q.cvGet.get(u2,c.id)||{vote:0}):{vote:0};return{...fmt(c),my_vote:v.vote};}

async function route(req,res){
  const parsed=url.parse(req.url,true);
  const p=parsed.pathname.replace(/\/$/,'')||'/';
  const q=parsed.query;
  const m=req.method;

  /* AUTH */
  if(p==='/api/auth/register'&&m==='POST'){
    const b=await readBody(req);
    const{username,name,email,password}=b;
    if(!username||!name||!email||!password)return json(res,{error:'Barcha maydonlar to\'ldirilishi shart'},400);
    if(password.length<6)return json(res,{error:'Parol kamida 6 belgi'},400);
    if(!/^[a-zA-Z0-9_]{3,20}$/.test(username))return json(res,{error:'Username: 3-20 belgi, faqat harf/raqam/_'},400);
    if(Q.uExists.get(username,email))return json(res,{error:'Bu username yoki email band'},409);
    const id=uid();
    Q.uInsert.run(id,username.toLowerCase(),name,email.toLowerCase(),hashPass(password),randColor());
    return json(res,{token:makeToken(id),user:Q.uById.get(id)},201);
  }
  if(p==='/api/auth/login'&&m==='POST'){
    const b=await readBody(req);
    const{username,password}=b;
    if(!username||!password)return json(res,{error:'Login va parolni kiriting'},400);
    const user=Q.uByLogin.get(username,username);
    if(!user||user.pass!==hashPass(password))return json(res,{error:'Noto\'g\'ri login yoki parol'},401);
    return json(res,{token:makeToken(user.id),user:Q.uById.get(user.id)});
  }

  /* ME */
  if(p==='/api/me'&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const user=Q.uById.get(u2);if(!user)return json(res,{error:'Topilmadi'},404);
    return json(res,{...user,online:true});
  }
  if(p==='/api/me'&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const b=await readBody(req);
    if(!b.name||!b.name.trim())return json(res,{error:'Ism bo\'sh bo\'lmasin'},400);
    Q.uUpdProf.run(b.name.trim(),(b.bio||'').trim(),u2);
    return json(res,Q.uById.get(u2));
  }
  if(p==='/api/me/avatar'&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const{file}=await parseMultipart(req);
    if(!file)return json(res,{error:'Rasm topilmadi'},400);
    const fn=`av_${u2}${file.ext}`;
    fs.writeFileSync(path.join(UPLOAD,fn),file.data);
    Q.uUpdAv.run(`/uploads/${fn}`,u2);
    return json(res,{avatar:`/uploads/${fn}`});
  }

  /* USERS */
  if(p==='/api/users/search'&&m==='GET'){
    const u2=getAuth(req);
    const t=(q.q||'').toLowerCase().trim();
    if(!t)return json(res,[]);
    return json(res,Q.uSearch.all(`%${t}%`,`%${t}%`));
  }
  if(p.match(/^\/api\/users\/[^/]+$/)&&m==='GET'){
    const u2=getAuth(req);
    const param=p.split('/')[3];
    const user=Q.uBySlug.get(param,param);
    if(!user)return json(res,{error:'Foydalanuvchi topilmadi'},404);
    const posts=Q.pByUser.all(user.id).map(r=>fmtPost(r,u2));
    return json(res,{...user,posts,online:ws.isOnline(user.id)});
  }

  /* COMMUNITIES */
  if(p==='/api/communities'&&m==='GET'){
    const u2=getAuth(req);
    return json(res,Q.comAll.all().map(c=>fmtCom(c,u2)));
  }
  if(p==='/api/communities/popular'&&m==='GET'){
    const u2=getAuth(req);
    return json(res,Q.comPopular.all().map(c=>fmtCom(c,u2)));
  }
  if(p==='/api/communities/mine'&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    return json(res,Q.comMine.all(u2).map(c=>fmtCom(c,u2)));
  }
  if(p==='/api/communities'&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const b=await readBody(req);
    const{slug,name,description,color}=b;
    if(!slug||!name)return json(res,{error:'Slug va nom kiritish shart'},400);
    const sl=slug.toLowerCase().trim();
    if(!/^[a-z0-9_]{2,25}$/.test(sl))return json(res,{error:'Slug: 2-25 belgi, faqat kichik harf/raqam/_'},400);
    if(Q.comBySlug.get(sl))return json(res,{error:'Bu jamoa nomi band'},409);
    const id=uid();
    Q.comInsert.run(id,sl,name,description||'',color||randColor(),u2);
    Q.memJoin.run(u2,id);
    return json(res,fmtCom(Q.comById.get(id),u2),201);
  }
  if(p.match(/^\/api\/communities\/[^/]+$/)&&m==='GET'){
    const u2=getAuth(req);
    const com=Q.comBySlug.get(p.split('/')[3]);
    if(!com)return json(res,{error:'Jamoa topilmadi'},404);
    return json(res,fmtCom(com,u2));
  }
  if(p.match(/^\/api\/communities\/[^/]+$/)&&m==='PUT'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const com=Q.comBySlug.get(p.split('/')[3]);
    if(!com)return json(res,{error:'Topilmadi'},404);
    if(com.owner_id!==u2)return json(res,{error:'Ruxsat yo\'q'},403);
    const b=await readBody(req);
    Q.comUpdate.run(b.name||com.name,b.description||com.description,b.rules||com.rules||'',b.color||com.color,com.id,u2);
    return json(res,fmtCom(Q.comById.get(com.id),u2));
  }
  if(p.match(/^\/api\/communities\/[^/]+\/join$/)&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const com=Q.comBySlug.get(p.split('/')[3]);
    if(!com)return json(res,{error:'Topilmadi'},404);
    if(Q.memCheck.get(u2,com.id)){Q.memLeave.run(u2,com.id);Q.comDecMem.run(com.id);return json(res,{joined:false});}
    Q.memJoin.run(u2,com.id);Q.comIncMem.run(com.id);
    return json(res,{joined:true});
  }

  /* POSTS */
  if(p==='/api/posts'&&m==='GET'){
    const u2=getAuth(req);
    const offset=parseInt(q.offset||'0')||0;
    const posts=(q.sort==='new'?Q.pNew:Q.pHot).all(offset);
    return json(res,posts.map(r=>fmtPost(r,u2)));
  }
  if(p.match(/^\/api\/communities\/[^/]+\/posts$/)&&m==='GET'){
    const u2=getAuth(req);
    const slug=p.split('/')[3];
    const offset=parseInt(q.offset||'0')||0;
    const posts=(q.sort==='new'?Q.pComNew:Q.pCom).all(slug,offset);
    return json(res,posts.map(r=>fmtPost(r,u2)));
  }
  if(p==='/api/posts/saved'&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    return json(res,Q.pSaved.all(u2).map(r=>fmtPost(r,u2)));
  }
  if(p.match(/^\/api\/posts\/[^/]+$/)&&m==='GET'){
    const u2=getAuth(req);
    const post=Q.pOne.get(p.split('/')[3]);
    if(!post)return json(res,{error:'Post topilmadi'},404);
    const comments=Q.cmByPost.all(post.id).map(c=>fmtComment(c,u2));
    return json(res,{...fmtPost(post,u2),comments});
  }
  if(p==='/api/posts'&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const ct=req.headers['content-type']||'';
    let title='',body='',comSlug='',type='text',link=null,image=null,flair=null;
    if(ct.includes('multipart')){
      const{fields,file}=await parseMultipart(req);
      title=(fields.title||'').trim();body=(fields.body||'').trim();
      comSlug=(fields.community||'').trim();type=fields.type||'text';
      link=fields.link||null;flair=fields.flair||null;
      if(file){const fn=uid()+file.ext;fs.writeFileSync(path.join(UPLOAD,fn),file.data);image=`/uploads/${fn}`;type='image';}
    } else {
      const b=await readBody(req);
      title=(b.title||'').trim();body=(b.body||'').trim();
      comSlug=(b.community||'').trim();type=b.type||'text';
      link=b.link||null;flair=b.flair||null;
    }
    if(!title)return json(res,{error:'Sarlavha kiritish shart'},400);
    if(!comSlug)return json(res,{error:'Jamoa tanlash shart'},400);
    const com=Q.comBySlug.get(comSlug);
    if(!com)return json(res,{error:'Jamoa topilmadi'},404);
    const pid=uid();
    Q.pInsert.run(pid,u2,com.id,title,body,link,image,type,flair);
    Q.pScore.run(1,1,0,pid);
    Q.pvUpsert.run(u2,pid,1);
    Q.uKarma.run(1,u2);
    const post=fmtPost(Q.pOne.get(pid),u2);
    ws.sendAll({type:'new_post',data:post});
    return json(res,post,201);
  }
  if(p.match(/^\/api\/posts\/[^/]+$/)&&m==='DELETE'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const pid=p.split('/')[3];
    const own=Q.pOwner.get(pid);if(!own)return json(res,{error:'Topilmadi'},404);
    if(own.user_id!==u2)return json(res,{error:'Ruxsat yo\'q'},403);
    Q.pDelete.run(pid,u2);
    ws.sendAll({type:'del_post',data:{id:pid}});
    return json(res,{ok:true});
  }

  /* VOTE POST */
  if(p.match(/^\/api\/posts\/[^/]+\/vote$/)&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const pid=p.split('/')[3];
    const own=Q.pOwner.get(pid);if(!own)return json(res,{error:'Topilmadi'},404);
    const b=await readBody(req);
    const vote=parseInt(b.vote);
    if(![1,-1].includes(vote))return json(res,{error:'Vote 1 yoki -1'},400);
    const ex=Q.pvGet.get(u2,pid);
    let myVote=vote;
    if(ex&&ex.vote===vote){Q.pvDelete.run(u2,pid);myVote=0;}
    else Q.pvUpsert.run(u2,pid,vote);
    const c=Q.pvCount.get(pid);
    const score=c.up-c.dn;
    Q.pScore.run(score,c.up,c.dn,pid);
    if(myVote===1&&own.user_id!==u2)Q.uKarma.run(1,own.user_id);
    if(myVote===-1&&own.user_id!==u2)Q.uKarma.run(-1,own.user_id);
    ws.sendAll({type:'vote_post',data:{postId:pid,score,upvotes:c.up,downvotes:c.dn,by:u2,vote:myVote}});
    return json(res,{score,upvotes:c.up,downvotes:c.dn,my_vote:myVote});
  }

  /* SAVE */
  if(p.match(/^\/api\/posts\/[^/]+\/save$/)&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const pid=p.split('/')[3];
    if(Q.svCheck.get(u2,pid)){Q.svDelete.run(u2,pid);return json(res,{saved:false});}
    Q.svInsert.run(u2,pid);
    return json(res,{saved:true});
  }

  /* SEARCH */
  if(p==='/api/search'&&m==='GET'){
    const u2=getAuth(req);
    const t=`%${(q.q||'').toLowerCase().trim()}%`;
    if(t==='%%')return json(res,{posts:[],communities:[],users:[]});
    return json(res,{
      posts:Q.pSearch.all(t,t).map(r=>fmtPost(r,u2)),
      communities:Q.comSearch.all(t,t).map(c=>fmtCom(c,u2)),
      users:Q.uSearch.all(t,t),
    });
  }

  /* COMMENTS */
  if(p.match(/^\/api\/posts\/[^/]+\/comments$/)&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const pid=p.split('/')[3];
    const b=await readBody(req);
    const body=(b.body||'').trim();
    if(!body)return json(res,{error:'Izoh bo\'sh bo\'lmasin'},400);
    const own=Q.pOwner.get(pid);if(!own)return json(res,{error:'Post topilmadi'},404);
    const parId=b.parent_id||null;
    let depth=0;
    if(parId){const par=Q.cmDepth.get(parId);if(par)depth=Math.min(par.depth+1,6);}
    const cid=uid();
    Q.cmInsert.run(cid,pid,u2,parId,body,depth);
    Q.cmScore.run(1,cid);
    Q.pIncCmt.run(pid);
    Q.uKarma.run(1,u2);
    const comment=fmtComment(Q.cmOne.get(cid),u2);
    ws.sendAll({type:'new_comment',data:{postId:pid,comment}});
    if(own.user_id!==u2){
      const from=Q.uById.get(u2);
      const nid=uid();
      Q.nInsert.run(nid,own.user_id,u2,'comment',pid,cid,`${from.name} sizning postingizga izoh qoldirdi 💬`);
      ws.sendTo(own.user_id,{type:'notif',data:{id:nid,type:'comment',msg:`${from.name} izoh qoldirdi 💬`,ago:'Hozir',is_read:0}});
    }
    return json(res,comment,201);
  }
  if(p.match(/^\/api\/comments\/[^/]+\/vote$/)&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const cid=p.split('/')[3];
    const own=Q.cmOwner.get(cid);if(!own)return json(res,{error:'Topilmadi'},404);
    const b=await readBody(req);
    const vote=parseInt(b.vote);
    if(![1,-1].includes(vote))return json(res,{error:'Vote 1 yoki -1'},400);
    const ex=Q.cvGet.get(u2,cid);
    let myVote=vote;
    if(ex&&ex.vote===vote){Q.cvDelete.run(u2,cid);myVote=0;}
    else Q.cvUpsert.run(u2,cid,vote);
    const c=Q.cvCount.get(cid);
    const score=c.up-c.dn;
    Q.cmScore.run(score,cid);
    if(myVote===1&&own.user_id!==u2)Q.uKarma.run(1,own.user_id);
    return json(res,{score,my_vote:myVote});
  }
  if(p.match(/^\/api\/comments\/[^/]+$/)&&m==='DELETE'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const cid=p.split('/')[3];
    const own=Q.cmOwner.get(cid);if(!own)return json(res,{error:'Topilmadi'},404);
    if(own.user_id!==u2)return json(res,{error:'Ruxsat yo\'q'},403);
    Q.cmDelete.run(cid,u2);
    ws.sendAll({type:'del_comment',data:{commentId:cid,postId:own.post_id}});
    return json(res,{ok:true});
  }

  /* NOTIFICATIONS */
  if(p==='/api/notifications'&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    return json(res,Q.nAll.all(u2).map(r=>({...r,ago:timeAgo(r.created_at)})));
  }
  if(p==='/api/notifications/read'&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    Q.nMarkRead.run(u2);return json(res,{ok:true});
  }
  if(p==='/api/notifications/count'&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    return json(res,{count:Q.nUnread.get(u2).c});
  }

  /* MESSAGES */
  if(p==='/api/messages'&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const pairs=Q.msgConvos.all(u2,u2,u2);
    const result=[];
    for(const{oid}of pairs){
      const other=Q.uById.get(oid);if(!other)continue;
      const last=Q.msgLast.get(u2,oid,oid,u2);
      result.push({other:{...other,online:ws.isOnline(other.id)},last:last?{...last,ago:timeAgo(last.created_at)}:null,unread:Q.msgUnread.get(u2).c});
    }
    return json(res,result);
  }
  if(p.match(/^\/api\/messages\/[^/]+$/)&&m==='GET'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const otherId=p.split('/')[3];
    Q.msgMarkRead.run(otherId,u2);
    return json(res,Q.msgThread.all(u2,otherId,otherId,u2).map(r=>({...r,ago:timeAgo(r.created_at)})));
  }
  if(p.match(/^\/api\/messages\/[^/]+$/)&&m==='POST'){
    const u2=getAuth(req);if(!u2)return json(res,{error:'Unauthorized'},401);
    const toId=p.split('/')[3];
    const toUser=Q.uById.get(toId);if(!toUser)return json(res,{error:'Foydalanuvchi topilmadi'},404);
    const b=await readBody(req);
    const body=(b.body||'').trim();
    if(!body)return json(res,{error:'Xabar bo\'sh bo\'lmasin'},400);
    const mid=uid();
    Q.msgInsert.run(mid,u2,toId,body);
    const from=Q.uById.get(u2);
    const msg={id:mid,from_id:u2,to_id:toId,body,is_read:0,ago:'Hozir',created_at:Math.floor(Date.now()/1000)};
    ws.sendTo(toId,{type:'new_msg',data:{msg,from:{id:from.id,name:from.name,username:from.username,color:from.color,avatar:from.avatar}}});
    ws.sendTo(u2,{type:'msg_sent',data:{msg}});
    return json(res,msg,201);
  }

  return null;
}
module.exports={route};
