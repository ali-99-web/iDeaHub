'use strict';
const path   = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const db = new DatabaseSync(path.join(__dirname, '..', 'ideahub.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id         TEXT PRIMARY KEY,
    username   TEXT UNIQUE NOT NULL COLLATE NOCASE,
    name       TEXT NOT NULL,
    email      TEXT UNIQUE NOT NULL COLLATE NOCASE,
    pass       TEXT NOT NULL,
    avatar     TEXT,
    color      TEXT DEFAULT '#FF4500',
    bio        TEXT DEFAULT '',
    karma      INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch())
  );
  CREATE TABLE IF NOT EXISTS communities (
    id          TEXT PRIMARY KEY,
    slug        TEXT UNIQUE NOT NULL COLLATE NOCASE,
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    rules       TEXT DEFAULT '',
    icon        TEXT,
    color       TEXT DEFAULT '#FF4500',
    owner_id    TEXT NOT NULL,
    members     INTEGER DEFAULT 1,
    created_at  INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY(owner_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS memberships (
    user_id      TEXT NOT NULL,
    community_id TEXT NOT NULL,
    PRIMARY KEY(user_id, community_id)
  );
  CREATE TABLE IF NOT EXISTS posts (
    id            TEXT PRIMARY KEY,
    user_id       TEXT NOT NULL,
    community_id  TEXT NOT NULL,
    title         TEXT NOT NULL,
    body          TEXT DEFAULT '',
    link          TEXT,
    image         TEXT,
    type          TEXT DEFAULT 'text',
    score         INTEGER DEFAULT 1,
    upvotes       INTEGER DEFAULT 1,
    downvotes     INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    flair         TEXT,
    created_at    INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY(user_id)      REFERENCES users(id)       ON DELETE CASCADE,
    FOREIGN KEY(community_id) REFERENCES communities(id) ON DELETE CASCADE
  );
  CREATE TABLE IF NOT EXISTS post_votes (
    user_id TEXT NOT NULL,
    post_id TEXT NOT NULL,
    vote    INTEGER NOT NULL,
    PRIMARY KEY(user_id, post_id)
  );
  CREATE TABLE IF NOT EXISTS comments (
    id         TEXT PRIMARY KEY,
    post_id    TEXT NOT NULL,
    user_id    TEXT NOT NULL,
    parent_id  TEXT,
    body       TEXT NOT NULL,
    score      INTEGER DEFAULT 1,
    depth      INTEGER DEFAULT 0,
    is_deleted INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY(post_id)   REFERENCES posts(id)    ON DELETE CASCADE,
    FOREIGN KEY(user_id)   REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY(parent_id) REFERENCES comments(id)
  );
  CREATE TABLE IF NOT EXISTS comment_votes (
    user_id    TEXT NOT NULL,
    comment_id TEXT NOT NULL,
    vote       INTEGER NOT NULL,
    PRIMARY KEY(user_id, comment_id)
  );
  CREATE TABLE IF NOT EXISTS saved_posts (
    user_id  TEXT NOT NULL,
    post_id  TEXT NOT NULL,
    saved_at INTEGER DEFAULT (unixepoch()),
    PRIMARY KEY(user_id, post_id)
  );
  CREATE TABLE IF NOT EXISTS notifications (
    id         TEXT PRIMARY KEY,
    to_id      TEXT NOT NULL,
    from_id    TEXT,
    type       TEXT NOT NULL,
    post_id    TEXT,
    comment_id TEXT,
    msg        TEXT NOT NULL,
    is_read    INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch())
  );
  CREATE TABLE IF NOT EXISTS messages (
    id         TEXT PRIMARY KEY,
    from_id    TEXT NOT NULL,
    to_id      TEXT NOT NULL,
    body       TEXT NOT NULL,
    is_read    INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch())
  );
`);

const Q = {
  /* users */
  uById:     db.prepare('SELECT id,username,name,email,color,bio,avatar,karma,created_at FROM users WHERE id=?'),
  uByLogin:  db.prepare('SELECT * FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?)'),
  uBySlug:   db.prepare('SELECT id,username,name,color,bio,avatar,karma,created_at FROM users WHERE lower(username)=lower(?) OR id=?'),
  uSearch:   db.prepare('SELECT id,username,name,color,avatar,karma FROM users WHERE lower(username) LIKE ? OR lower(name) LIKE ? LIMIT 20'),
  uInsert:   db.prepare('INSERT INTO users(id,username,name,email,pass,color) VALUES(?,?,?,?,?,?)'),
  uExists:   db.prepare('SELECT id FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?)'),
  uUpdProf:  db.prepare('UPDATE users SET name=?,bio=? WHERE id=?'),
  uUpdAv:    db.prepare('UPDATE users SET avatar=? WHERE id=?'),
  uKarma:    db.prepare('UPDATE users SET karma=karma+? WHERE id=?'),

  /* communities */
  comAll:     db.prepare('SELECT c.*,u.username as oname FROM communities c JOIN users u ON c.owner_id=u.id ORDER BY c.members DESC LIMIT 60'),
  comById:    db.prepare('SELECT c.*,u.username as oname FROM communities c JOIN users u ON c.owner_id=u.id WHERE c.id=?'),
  comBySlug:  db.prepare('SELECT c.*,u.username as oname FROM communities c JOIN users u ON c.owner_id=u.id WHERE lower(c.slug)=lower(?)'),
  comSearch:  db.prepare('SELECT c.*,u.username as oname FROM communities c JOIN users u ON c.owner_id=u.id WHERE lower(c.slug) LIKE ? OR lower(c.name) LIKE ? LIMIT 20'),
  comInsert:  db.prepare('INSERT INTO communities(id,slug,name,description,color,owner_id) VALUES(?,?,?,?,?,?)'),
  comUpdate:  db.prepare('UPDATE communities SET name=?,description=?,rules=?,color=? WHERE id=? AND owner_id=?'),
  comIncMem:  db.prepare('UPDATE communities SET members=members+1 WHERE id=?'),
  comDecMem:  db.prepare('UPDATE communities SET members=MAX(0,members-1) WHERE id=?'),
  comPopular: db.prepare('SELECT c.*,u.username as oname FROM communities c JOIN users u ON c.owner_id=u.id ORDER BY c.members DESC LIMIT 10'),
  comMine:    db.prepare('SELECT c.*,u.username as oname FROM communities c JOIN users u ON c.owner_id=u.id JOIN memberships m ON m.community_id=c.id WHERE m.user_id=? ORDER BY c.members DESC'),

  /* memberships */
  memCheck: db.prepare('SELECT 1 FROM memberships WHERE user_id=? AND community_id=?'),
  memJoin:  db.prepare('INSERT OR IGNORE INTO memberships(user_id,community_id) VALUES(?,?)'),
  memLeave: db.prepare('DELETE FROM memberships WHERE user_id=? AND community_id=?'),

  /* posts */
  pHot:    db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id ORDER BY p.score DESC,p.created_at DESC LIMIT 25 OFFSET ?'),
  pNew:    db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id ORDER BY p.created_at DESC LIMIT 25 OFFSET ?'),
  pCom:    db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id WHERE lower(c.slug)=lower(?) ORDER BY p.score DESC,p.created_at DESC LIMIT 25 OFFSET ?'),
  pComNew: db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id WHERE lower(c.slug)=lower(?) ORDER BY p.created_at DESC LIMIT 25 OFFSET ?'),
  pByUser: db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id WHERE p.user_id=? ORDER BY p.created_at DESC LIMIT 25'),
  pOne:    db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id WHERE p.id=?'),
  pInsert: db.prepare('INSERT INTO posts(id,user_id,community_id,title,body,link,image,type,flair) VALUES(?,?,?,?,?,?,?,?,?)'),
  pDelete: db.prepare('DELETE FROM posts WHERE id=? AND user_id=?'),
  pOwner:  db.prepare('SELECT user_id,community_id FROM posts WHERE id=?'),
  pScore:  db.prepare('UPDATE posts SET score=?,upvotes=?,downvotes=? WHERE id=?'),
  pIncCmt: db.prepare('UPDATE posts SET comment_count=comment_count+1 WHERE id=?'),
  pSearch: db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id WHERE lower(p.title) LIKE ? OR lower(p.body) LIKE ? ORDER BY p.score DESC LIMIT 20'),
  pSaved:  db.prepare('SELECT p.*,u.username,u.color,u.avatar,c.slug as cslug,c.name as cname,c.color as ccolor,c.icon as cicon FROM posts p JOIN users u ON p.user_id=u.id JOIN communities c ON p.community_id=c.id JOIN saved_posts sp ON sp.post_id=p.id WHERE sp.user_id=? ORDER BY sp.saved_at DESC'),

  /* votes */
  pvGet:    db.prepare('SELECT vote FROM post_votes WHERE user_id=? AND post_id=?'),
  pvUpsert: db.prepare('INSERT INTO post_votes(user_id,post_id,vote) VALUES(?,?,?) ON CONFLICT(user_id,post_id) DO UPDATE SET vote=excluded.vote'),
  pvDelete: db.prepare('DELETE FROM post_votes WHERE user_id=? AND post_id=?'),
  pvCount:  db.prepare('SELECT COALESCE(SUM(CASE WHEN vote=1 THEN 1 ELSE 0 END),0) as up,COALESCE(SUM(CASE WHEN vote=-1 THEN 1 ELSE 0 END),0) as dn FROM post_votes WHERE post_id=?'),

  /* saved */
  svCheck:  db.prepare('SELECT 1 FROM saved_posts WHERE user_id=? AND post_id=?'),
  svInsert: db.prepare('INSERT OR IGNORE INTO saved_posts(user_id,post_id) VALUES(?,?)'),
  svDelete: db.prepare('DELETE FROM saved_posts WHERE user_id=? AND post_id=?'),

  /* comments */
  cmByPost: db.prepare('SELECT cm.*,u.username,u.color,u.avatar FROM comments cm JOIN users u ON cm.user_id=u.id WHERE cm.post_id=? ORDER BY cm.score DESC,cm.depth ASC,cm.created_at ASC'),
  cmInsert: db.prepare('INSERT INTO comments(id,post_id,user_id,parent_id,body,depth) VALUES(?,?,?,?,?,?)'),
  cmOne:    db.prepare('SELECT cm.*,u.username,u.color,u.avatar FROM comments cm JOIN users u ON cm.user_id=u.id WHERE cm.id=?'),
  cmOwner:  db.prepare('SELECT user_id,post_id FROM comments WHERE id=?'),
  cmDelete: db.prepare("UPDATE comments SET is_deleted=1,body='[o''chirildi]' WHERE id=? AND user_id=?"),
  cmScore:  db.prepare('UPDATE comments SET score=? WHERE id=?'),
  cmDepth:  db.prepare('SELECT depth FROM comments WHERE id=?'),

  cvGet:    db.prepare('SELECT vote FROM comment_votes WHERE user_id=? AND comment_id=?'),
  cvUpsert: db.prepare('INSERT INTO comment_votes(user_id,comment_id,vote) VALUES(?,?,?) ON CONFLICT(user_id,comment_id) DO UPDATE SET vote=excluded.vote'),
  cvDelete: db.prepare('DELETE FROM comment_votes WHERE user_id=? AND comment_id=?'),
  cvCount:  db.prepare('SELECT COALESCE(SUM(CASE WHEN vote=1 THEN 1 ELSE 0 END),0) as up,COALESCE(SUM(CASE WHEN vote=-1 THEN 1 ELSE 0 END),0) as dn FROM comment_votes WHERE comment_id=?'),

  /* notifs */
  nInsert:   db.prepare('INSERT INTO notifications(id,to_id,from_id,type,post_id,comment_id,msg) VALUES(?,?,?,?,?,?,?)'),
  nAll:      db.prepare('SELECT n.*,u.username as fn,u.color as fc,u.avatar as fa FROM notifications n LEFT JOIN users u ON n.from_id=u.id WHERE n.to_id=? ORDER BY n.created_at DESC LIMIT 60'),
  nMarkRead: db.prepare('UPDATE notifications SET is_read=1 WHERE to_id=?'),
  nUnread:   db.prepare('SELECT COUNT(*) as c FROM notifications WHERE to_id=? AND is_read=0'),

  /* messages */
  msgConvos:   db.prepare('SELECT DISTINCT CASE WHEN from_id=? THEN to_id ELSE from_id END as oid FROM messages WHERE from_id=? OR to_id=?'),
  msgThread:   db.prepare('SELECT * FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?) ORDER BY created_at ASC LIMIT 100'),
  msgInsert:   db.prepare('INSERT INTO messages(id,from_id,to_id,body) VALUES(?,?,?,?)'),
  msgMarkRead: db.prepare('UPDATE messages SET is_read=1 WHERE from_id=? AND to_id=?'),
  msgLast:     db.prepare('SELECT * FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?) ORDER BY created_at DESC LIMIT 1'),
  msgUnread:   db.prepare('SELECT COUNT(*) as c FROM messages WHERE to_id=? AND is_read=0'),
};

/* ─── Seed ─── */
function hmac(s){ return crypto.createHmac('sha256','ideahub_2025').update(s).digest('hex'); }

const U={ ali:'u_ali', zara:'u_zara', bekzod:'u_bekzod', malika:'u_malika' };
const C={ tech:'c_tech', sport:'c_sport', uzb:'c_uzb', music:'c_music', ilm:'c_ilm', kulgu:'c_kulgu' };

(function seed(){
  const users=[
    {id:U.ali,    un:'ali_dev',    nm:'Ali Karimov',    em:'ali@ideahub.uz',    col:'#FF4500', bio:'Full-stack dasturchi | Toshkent | React, Node.js'},
    {id:U.zara,   un:'zara_uz',    nm:'Zara Yusupova',  em:'zara@ideahub.uz',   col:'#0079D3', bio:'Jurnalist & Blogger | Samarqand'},
    {id:U.bekzod, un:'bekzod_pro', nm:'Bekzod Toshev',  em:'bekzod@ideahub.uz', col:'#46D160', bio:'Sport muhbiri | Andijon'},
    {id:U.malika, un:'malika_art', nm:'Malika Rahimova', em:'malika@ideahub.uz', col:'#7E53C1', bio:'Rassoma & UX Dizayner | Buxoro'},
  ];
  for(const u of users){
    if(!Q.uById.get(u.id)){
      Q.uInsert.run(u.id,u.un,u.nm,u.em,hmac('password123'),u.col);
      Q.uUpdProf.run(u.nm,u.bio,u.id);
      Q.uKarma.run(Math.floor(Math.random()*5000+500),u.id);
    }
  }

  const coms=[
    {id:C.tech,  slug:'texnologiya',nm:'Texnologiya', desc:'O\'zbekistonda IT, dasturlash, AI va texnologiya yangiliklari.',  col:'#0079D3'},
    {id:C.sport, slug:'sport',      nm:'Sport',       desc:'O\'zbek sporti — futbol, kurash, boks va boshqa sport turlari.',   col:'#46D160'},
    {id:C.uzb,   slug:'ozbekiston', nm:'O\'zbekiston', desc:'Vatanimiz haqida — madaniyat, yangiliklar, tarix, sayohat.',       col:'#FF4500'},
    {id:C.music, slug:'musiqa',     nm:'Musiqa',      desc:'O\'zbek va jahon musiqasi, artistlar, konsertlar.',                col:'#7E53C1'},
    {id:C.ilm,   slug:'ilm',        nm:'Ilm-Fan',     desc:'Fan, ta\'lim, kashfiyotlar, kitoblar va bilim almashish.',         col:'#FFD635'},
    {id:C.kulgu, slug:'kulgu',      nm:'Kulgu & Mem', desc:'Kulgili rasmlar, memlar, hazillar. Kayfiyatingizni ko\'taring!',  col:'#EA0027'},
  ];
  for(const c of coms){
    if(!Q.comById.get(c.id)){
      Q.comInsert.run(c.id,c.slug,c.nm,c.desc,c.col,U.ali);
      for(const uid of Object.values(U)){ Q.memJoin.run(uid,c.id); }
      db.prepare('UPDATE communities SET members=4 WHERE id=?').run(c.id);
    }
  }

  const posts=[
    {id:'p1', uid:U.ali,    cid:C.tech,  title:'O\'zbekistonda IT sohasida ishlash tajribam — 3 yil!',           body:'3 yil oldin dasturlashni boshlaganimda hech narsa bilmasardim. Endi senior developer bo\'ldim. O\'z yo\'limni, to\'siqlarni va muvaffaqiyatlarni yozib qoldirdim...',         sc:342},
    {id:'p2', uid:U.zara,   cid:C.uzb,   title:'Samarqandga sayohat — Registon haqida haqiqat',                  body:'O\'tgan hafta Samarqandga bordim. Registon maydoni — dunyo mo\'jizalaridan biri! Fotolar va to\'liq taassurotlarim...',                                                 sc:287},
    {id:'p3', uid:U.bekzod, cid:C.sport, title:'O\'zbekiston U23 — Osiyo chempionatida tarixiy g\'alaba! 🏆',    body:'Bugun tarixiy g\'alaba qo\'lga kiritildi! Bizning yigitlar final o\'ynaydi. O\'yinni ko\'rdingizmi? Taassurotlarimni baham ko\'raman...',                              sc:523},
    {id:'p4', uid:U.malika, cid:C.music, title:'Ulug\'bek Rahmatullayev — yangi albom tahlili',                   body:'Yangi albom chiqdi va har bir qo\'shiq — she\'r. Mening sevimlilarim va ba\'zi tanqidlarim...',                                                                        sc:198},
    {id:'p5', uid:U.ali,    cid:C.ilm,   title:'Kvant kompyuterlari nimaga kerak? Oddiy tilda tushuntiraman',     body:'Ko\'pchilik kvant kompyuterlar haqida eshitgan, lekin nima ekanligini bilmaydi. Bugun sodda tilda tushuntiraman, misollar bilan...',                                   sc:412},
    {id:'p6', uid:U.zara,   cid:C.kulgu, title:'O\'zbek onasining har kuni: "Ovqat yedingmi?" 😂',               body:'Tanish bo\'lsa like bos! Qorin to\'q bo\'lsa ham, och bo\'lsa ham — savol bir xil. Bu bizning madaniyatimiz — va men uni sevaman!',                                    sc:634},
    {id:'p7', uid:U.bekzod, cid:C.tech,  title:'ChatGPT ni o\'zbek tilida ishlatish — bir oylik tajribam',        body:'Bir oy davomida ChatGPT ni faqat o\'zbek tilida ishlatib ko\'rdim. Natijalar kutilganidan yaxshi chiqdi! Batafsil yozaman...',                                         sc:267},
    {id:'p8', uid:U.malika, cid:C.uzb,   title:'Toshkentdagi eng yaxshi 10 ta choyxona 🍵',                       body:'Choyxona — bu faqat choy emas, bu madaniyat! Men bir oy davomida 10 ta eng yaxshi choyxonani topib keldim. Har biri haqida batafsil...',                               sc:445},
    {id:'p9', uid:U.ali,    cid:C.tech,  title:'Node.js vs Python — backend uchun qaysi biri to\'g\'ri?',        body:'Ikkisini ham yaxshi bilaman va ikkalasida ham loyihalar qilganman. Ularni solishtirib, qaysi proyekt uchun qaysi biri to\'g\'ri kelishini tushuntiraman.',              sc:389},
    {id:'p10',uid:U.zara,   cid:C.ilm,   title:'O\'zbekistonda ta\'lim tizimi — muammo va yechimlar',             body:'Ta\'lim sohasida 5 yil ishlaganman va ko\'p muammolarni o\'z ko\'zim bilan ko\'rganman. Yechimlar haqida fikrlarimni o\'rtoqlashaman...',                               sc:301},
    {id:'p11',uid:U.bekzod, cid:C.sport, title:'Jahon chempionatiga tayyorgarlik — Hamza Meding intervyu',        body:'Hamza Meding — O\'zbekistonning eng mashhur bokschilaridan biri bilan so\'zlashdim. Uning tayyorgarlik jarayoni haqida...',                                           sc:478},
    {id:'p12',uid:U.malika, cid:C.music, title:'O\'zbek pop musiqasi: qayerga ketyapmiz?',                        body:'So\'nggi 5 yilda o\'zbek pop musiqasi qanday o\'zgardi? Ijobiy va salbiy tomonlari, va kelajak haqida fikrlarim...',                                                  sc:334},
  ];

  const pCheck=db.prepare('SELECT id FROM posts WHERE id=?');
  for(const p of posts){
    if(!pCheck.get(p.id)){
      Q.pInsert.run(p.id,p.uid,p.cid,p.title,p.body,null,null,'text',null);
      Q.pScore.run(p.sc,p.sc,0,p.id);
    }
  }

  const cms=[
    {id:'cm1', pid:'p1', uid:U.zara,   par:null,  body:'Ajoyib maqola! Men ham 6 oy bo\'ldi o\'rganayapman. Qayerdan boshladingiz?', sc:45, d:0},
    {id:'cm2', pid:'p1', uid:U.ali,    par:'cm1', body:'React va Node.js dan boshladim. YouTube va Udemy juda yaxshi resurs!',       sc:23, d:1},
    {id:'cm3', pid:'p1', uid:U.bekzod, par:null,  body:'IT sohasiga o\'tishni rejalashtiraman. Oyiga qancha ishlash mumkin?',        sc:18, d:0},
    {id:'cm4', pid:'p1', uid:U.malika, par:'cm3', body:'Boshida kam, lekin 2-3 yildan keyin juda yaxshi. Sabr kerak!',               sc:12, d:1},
    {id:'cm5', pid:'p3', uid:U.ali,    par:null,  body:'Go\'lni ko\'rdingizmi?! Hayot! 🔥🔥🔥',                                     sc:87, d:0},
    {id:'cm6', pid:'p3', uid:U.malika, par:null,  body:'Stadiondan yozdim! Atmosfera ihonat edi!',                                  sc:54, d:0},
    {id:'cm7', pid:'p6', uid:U.bekzod, par:null,  body:'😂😂😂 Juda tanish! Biznikida ham xuddi shunday!',                         sc:92, d:0},
    {id:'cm8', pid:'p6', uid:U.ali,    par:'cm7', body:'Universal o\'zbek onasi dasturi 😄 Har kuni shu gap!',                       sc:67, d:1},
    {id:'cm9', pid:'p5', uid:U.malika, par:null,  body:'Nihoyat tushunarli tushuntirish! Ko\'p vaqtdan beri izlardim. Rahmat!',      sc:38, d:0},
    {id:'cm10',pid:'p2', uid:U.bekzod, par:null,  body:'Samarqand — dunyoning eng go\'zal shahri! Shu yil bordim, hayratlanarli!',  sc:29, d:0},
  ];

  const cmCheck=db.prepare('SELECT id FROM comments WHERE id=?');
  for(const c of cms){
    if(!cmCheck.get(c.id)){
      Q.cmInsert.run(c.id,c.pid,c.uid,c.par,c.body,c.d);
      Q.cmScore.run(c.sc,c.id);
      Q.pIncCmt.run(c.pid);
    }
  }
})();

module.exports = { db, Q, hmac };
